﻿namespace WindowsFormsApp1
{
    partial class Temperatuur
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea12 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend12 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series12 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title12 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea11 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend11 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series11 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title11 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea10 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend10 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series10 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title10 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea9 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend9 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series9 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title9 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea8 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend8 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series8 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title8 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.Windows.Forms.DataVisualization.Charting.ChartArea chartArea7 = new System.Windows.Forms.DataVisualization.Charting.ChartArea();
            System.Windows.Forms.DataVisualization.Charting.Legend legend7 = new System.Windows.Forms.DataVisualization.Charting.Legend();
            System.Windows.Forms.DataVisualization.Charting.Series series7 = new System.Windows.Forms.DataVisualization.Charting.Series();
            System.Windows.Forms.DataVisualization.Charting.Title title7 = new System.Windows.Forms.DataVisualization.Charting.Title();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Temperatuur));
            this.messageQueue1 = new System.Messaging.MessageQueue();
            this.BtnOpvragenVanTot = new System.Windows.Forms.Button();
            this.DtpTot = new System.Windows.Forms.DateTimePicker();
            this.LblTot = new System.Windows.Forms.Label();
            this.LblVan = new System.Windows.Forms.Label();
            this.DtpVan = new System.Windows.Forms.DateTimePicker();
            this.BtnLocatieSensorOpslaan = new System.Windows.Forms.Button();
            this.BtnLogout = new System.Windows.Forms.Button();
            this.Instellingen = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.test2ToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.roodToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.witToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.blauwToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.grijsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.groenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.geelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.orgineelToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.linksToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.websiteToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.mobieleApplicatieToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exportDataToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.screenshotGrafiekToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.beschikbareTalenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.nederlandsToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.meldingenUitschakelenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.inschakelenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.ontvangerToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.helpToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.contactToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fullScreenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.fullScreenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.maximaalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.minimaalToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.meldingServiceToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minutenToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minutenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.minutenToolStripMenuItem2 = new System.Windows.Forms.ToolStripMenuItem();
            this.btnInstellingen = new System.Windows.Forms.Button();
            this.GrafiekTemperatuur = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.tblTemperatureBindingSource = new System.Windows.Forms.BindingSource(this.components);
            this.temperatuurDataSet = new WindowsFormsApp1.temperatuurDataSet();
            this.timer1 = new System.Windows.Forms.Timer(this.components);
            this.BtnTimerStart1 = new System.Windows.Forms.Button();
            this.BtnTimerStop1 = new System.Windows.Forms.Button();
            this.LblRealTime1 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.timer2 = new System.Windows.Forms.Timer(this.components);
            this.tbl_TemperatureTableAdapter = new WindowsFormsApp1.temperatuurDataSetTableAdapters.tbl_TemperatureTableAdapter();
            this.GrafiekKelvin1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.grafiekFarhenheid1 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.GrafiekTemperatuur2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.grafiekFarhenheid2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.GrafiekKelvin2 = new System.Windows.Forms.DataVisualization.Charting.Chart();
            this.BtnRefreshLocation = new System.Windows.Forms.Button();
            this.PnlSensor2 = new System.Windows.Forms.Panel();
            this.BtnS2 = new System.Windows.Forms.Button();
            this.LblSensor2 = new System.Windows.Forms.Label();
            this.TxbSelectedSensor2 = new System.Windows.Forms.TextBox();
            this.TbMinimumTemperatuur2 = new System.Windows.Forms.TextBox();
            this.LblMinimumTemperatuur2 = new System.Windows.Forms.Label();
            this.TbMaximumTemperatuur2 = new System.Windows.Forms.TextBox();
            this.LblMaximumTemperatuur2 = new System.Windows.Forms.Label();
            this.RdbFarhenheid2 = new System.Windows.Forms.RadioButton();
            this.RdbKelvin2 = new System.Windows.Forms.RadioButton();
            this.RdbCelsius2 = new System.Windows.Forms.RadioButton();
            this.BtnSettingsSensor2 = new System.Windows.Forms.Button();
            this.PnlHeader = new System.Windows.Forms.Panel();
            this.label2 = new System.Windows.Forms.Label();
            this.PnlFooter = new System.Windows.Forms.Panel();
            this.TxbPcUser = new System.Windows.Forms.TextBox();
            this.TxbLastConnTime = new System.Windows.Forms.TextBox();
            this.label3 = new System.Windows.Forms.Label();
            this.TxbUserLoggedIn = new System.Windows.Forms.TextBox();
            this.LblUserApp = new System.Windows.Forms.Label();
            this.LblPc = new System.Windows.Forms.Label();
            this.BtnStatusSqlConnection = new System.Windows.Forms.Button();
            this.LblStatusSql = new System.Windows.Forms.Label();
            this.fullScreenToolStripMenuItem1 = new System.Windows.Forms.ToolStripMenuItem();
            this.maximaalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.minimaalToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.TimerStatusSQL = new System.Windows.Forms.Timer(this.components);
            this.LblSensor1Active = new System.Windows.Forms.Label();
            this.LblSensor2Active = new System.Windows.Forms.Label();
            this.LblMaximumTemperatuur1 = new System.Windows.Forms.Label();
            this.TbMaximumTemperatuur1 = new System.Windows.Forms.TextBox();
            this.LblMinimumTemperatuur1 = new System.Windows.Forms.Label();
            this.TbMinimumTemperatuur1 = new System.Windows.Forms.TextBox();
            this.RdbCelsius1 = new System.Windows.Forms.RadioButton();
            this.RdbKelvin1 = new System.Windows.Forms.RadioButton();
            this.RdbFarhenheid1 = new System.Windows.Forms.RadioButton();
            this.BtnSettingsSensor1 = new System.Windows.Forms.Button();
            this.TxbSelectedSensor1 = new System.Windows.Forms.TextBox();
            this.Btns1 = new System.Windows.Forms.Button();
            this.LblSensor1 = new System.Windows.Forms.Label();
            this.PnlSensor1 = new System.Windows.Forms.Panel();
            this.Btns21 = new System.Windows.Forms.Button();
            this.BtnS22 = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.Instellingen.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekTemperatuur)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblTemperatureBindingSource)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.temperatuurDataSet)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekKelvin1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grafiekFarhenheid1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekTemperatuur2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.grafiekFarhenheid2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekKelvin2)).BeginInit();
            this.PnlSensor2.SuspendLayout();
            this.PnlHeader.SuspendLayout();
            this.PnlFooter.SuspendLayout();
            this.PnlSensor1.SuspendLayout();
            this.SuspendLayout();
            // 
            // messageQueue1
            // 
            this.messageQueue1.MessageReadPropertyFilter.LookupId = true;
            this.messageQueue1.SynchronizingObject = this;
            // 
            // BtnOpvragenVanTot
            // 
            this.BtnOpvragenVanTot.Location = new System.Drawing.Point(488, 273);
            this.BtnOpvragenVanTot.Name = "BtnOpvragenVanTot";
            this.BtnOpvragenVanTot.Size = new System.Drawing.Size(75, 23);
            this.BtnOpvragenVanTot.TabIndex = 93;
            this.BtnOpvragenVanTot.Text = "Opvragen";
            this.BtnOpvragenVanTot.UseVisualStyleBackColor = true;
            this.BtnOpvragenVanTot.Click += new System.EventHandler(this.BtnOpvragenVanTot_Click);
            // 
            // DtpTot
            // 
            this.DtpTot.Location = new System.Drawing.Point(282, 275);
            this.DtpTot.MaxDate = new System.DateTime(2050, 1, 1, 0, 0, 0, 0);
            this.DtpTot.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.DtpTot.Name = "DtpTot";
            this.DtpTot.Size = new System.Drawing.Size(200, 20);
            this.DtpTot.TabIndex = 92;
            this.DtpTot.ValueChanged += new System.EventHandler(this.DtpTot_ValueChanged);
            // 
            // LblTot
            // 
            this.LblTot.AutoSize = true;
            this.LblTot.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblTot.Location = new System.Drawing.Point(253, 279);
            this.LblTot.Name = "LblTot";
            this.LblTot.Size = new System.Drawing.Size(26, 13);
            this.LblTot.TabIndex = 91;
            this.LblTot.Text = "Tot:";
            // 
            // LblVan
            // 
            this.LblVan.AutoSize = true;
            this.LblVan.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblVan.Location = new System.Drawing.Point(12, 279);
            this.LblVan.Name = "LblVan";
            this.LblVan.Size = new System.Drawing.Size(29, 13);
            this.LblVan.TabIndex = 90;
            this.LblVan.Text = "Van:";
            // 
            // DtpVan
            // 
            this.DtpVan.Location = new System.Drawing.Point(47, 275);
            this.DtpVan.MaxDate = new System.DateTime(2050, 1, 1, 0, 0, 0, 0);
            this.DtpVan.MinDate = new System.DateTime(2017, 1, 1, 0, 0, 0, 0);
            this.DtpVan.Name = "DtpVan";
            this.DtpVan.Size = new System.Drawing.Size(200, 20);
            this.DtpVan.TabIndex = 89;
            this.DtpVan.Value = new System.DateTime(2017, 11, 9, 0, 0, 0, 0);
            this.DtpVan.ValueChanged += new System.EventHandler(this.DtpVan_ValueChanged);
            // 
            // BtnLocatieSensorOpslaan
            // 
            this.BtnLocatieSensorOpslaan.Location = new System.Drawing.Point(0, 0);
            this.BtnLocatieSensorOpslaan.Name = "BtnLocatieSensorOpslaan";
            this.BtnLocatieSensorOpslaan.Size = new System.Drawing.Size(75, 23);
            this.BtnLocatieSensorOpslaan.TabIndex = 158;
            // 
            // BtnLogout
            // 
            this.BtnLogout.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.BtnLogout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.BtnLogout.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnLogout.BackgroundImage")));
            this.BtnLogout.Font = new System.Drawing.Font("Microsoft Sans Serif", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.BtnLogout.Location = new System.Drawing.Point(943, 0);
            this.BtnLogout.Name = "BtnLogout";
            this.BtnLogout.Size = new System.Drawing.Size(50, 50);
            this.BtnLogout.TabIndex = 130;
            this.BtnLogout.UseVisualStyleBackColor = false;
            this.BtnLogout.Click += new System.EventHandler(this.BtnLogout_Click);
            // 
            // Instellingen
            // 
            this.Instellingen.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.test2ToolStripMenuItem,
            this.linksToolStripMenuItem,
            this.exportDataToolStripMenuItem,
            this.beschikbareTalenToolStripMenuItem,
            this.meldingenUitschakelenToolStripMenuItem,
            this.helpToolStripMenuItem,
            this.contactToolStripMenuItem,
            this.fullScreenToolStripMenuItem,
            this.meldingServiceToolStripMenuItem});
            this.Instellingen.Name = "contextMenuStrip1";
            this.Instellingen.Size = new System.Drawing.Size(170, 202);
            // 
            // test2ToolStripMenuItem
            // 
            this.test2ToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.roodToolStripMenuItem,
            this.witToolStripMenuItem,
            this.blauwToolStripMenuItem,
            this.grijsToolStripMenuItem,
            this.groenToolStripMenuItem,
            this.geelToolStripMenuItem,
            this.orgineelToolStripMenuItem});
            this.test2ToolStripMenuItem.Name = "test2ToolStripMenuItem";
            this.test2ToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.test2ToolStripMenuItem.Text = "Kleur achtergrond";
            // 
            // roodToolStripMenuItem
            // 
            this.roodToolStripMenuItem.Name = "roodToolStripMenuItem";
            this.roodToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.roodToolStripMenuItem.Text = "Rood";
            this.roodToolStripMenuItem.Click += new System.EventHandler(this.RoodToolStripMenuItem_Click);
            // 
            // witToolStripMenuItem
            // 
            this.witToolStripMenuItem.Name = "witToolStripMenuItem";
            this.witToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.witToolStripMenuItem.Text = "Wit";
            this.witToolStripMenuItem.Click += new System.EventHandler(this.WitToolStripMenuItem_Click);
            // 
            // blauwToolStripMenuItem
            // 
            this.blauwToolStripMenuItem.Name = "blauwToolStripMenuItem";
            this.blauwToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.blauwToolStripMenuItem.Text = "Blauw";
            this.blauwToolStripMenuItem.Click += new System.EventHandler(this.BlauwToolStripMenuItem_Click);
            // 
            // grijsToolStripMenuItem
            // 
            this.grijsToolStripMenuItem.Name = "grijsToolStripMenuItem";
            this.grijsToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.grijsToolStripMenuItem.Text = "Grijs";
            this.grijsToolStripMenuItem.Click += new System.EventHandler(this.GrijsToolStripMenuItem_Click);
            // 
            // groenToolStripMenuItem
            // 
            this.groenToolStripMenuItem.Name = "groenToolStripMenuItem";
            this.groenToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.groenToolStripMenuItem.Text = "Groen";
            this.groenToolStripMenuItem.Click += new System.EventHandler(this.GroenToolStripMenuItem_Click);
            // 
            // geelToolStripMenuItem
            // 
            this.geelToolStripMenuItem.Name = "geelToolStripMenuItem";
            this.geelToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.geelToolStripMenuItem.Text = "Geel";
            this.geelToolStripMenuItem.Click += new System.EventHandler(this.GeelToolStripMenuItem_Click);
            // 
            // orgineelToolStripMenuItem
            // 
            this.orgineelToolStripMenuItem.Name = "orgineelToolStripMenuItem";
            this.orgineelToolStripMenuItem.Size = new System.Drawing.Size(122, 22);
            this.orgineelToolStripMenuItem.Text = "Origineel";
            this.orgineelToolStripMenuItem.Click += new System.EventHandler(this.OrigineelToolStripMenuItem_Click);
            // 
            // linksToolStripMenuItem
            // 
            this.linksToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.websiteToolStripMenuItem,
            this.mobieleApplicatieToolStripMenuItem});
            this.linksToolStripMenuItem.Name = "linksToolStripMenuItem";
            this.linksToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.linksToolStripMenuItem.Text = "Links";
            // 
            // websiteToolStripMenuItem
            // 
            this.websiteToolStripMenuItem.Name = "websiteToolStripMenuItem";
            this.websiteToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.websiteToolStripMenuItem.Text = "Website";
            this.websiteToolStripMenuItem.Click += new System.EventHandler(this.WebsiteToolStripMenuItem_Click);
            // 
            // mobieleApplicatieToolStripMenuItem
            // 
            this.mobieleApplicatieToolStripMenuItem.Name = "mobieleApplicatieToolStripMenuItem";
            this.mobieleApplicatieToolStripMenuItem.Size = new System.Drawing.Size(173, 22);
            this.mobieleApplicatieToolStripMenuItem.Text = "Mobiele Applicatie";
            this.mobieleApplicatieToolStripMenuItem.Click += new System.EventHandler(this.MobieleApplicatieToolStripMenuItem_Click);
            // 
            // exportDataToolStripMenuItem
            // 
            this.exportDataToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.screenshotGrafiekToolStripMenuItem});
            this.exportDataToolStripMenuItem.Name = "exportDataToolStripMenuItem";
            this.exportDataToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.exportDataToolStripMenuItem.Text = "Export";
            this.exportDataToolStripMenuItem.Click += new System.EventHandler(this.ExportDataToolStripMenuItem_Click);
            // 
            // screenshotGrafiekToolStripMenuItem
            // 
            this.screenshotGrafiekToolStripMenuItem.Name = "screenshotGrafiekToolStripMenuItem";
            this.screenshotGrafiekToolStripMenuItem.Size = new System.Drawing.Size(171, 22);
            this.screenshotGrafiekToolStripMenuItem.Text = "Screenshot grafiek";
            this.screenshotGrafiekToolStripMenuItem.Click += new System.EventHandler(this.screenshotGrafiekToolStripMenuItem_Click);
            // 
            // beschikbareTalenToolStripMenuItem
            // 
            this.beschikbareTalenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.nederlandsToolStripMenuItem});
            this.beschikbareTalenToolStripMenuItem.Name = "beschikbareTalenToolStripMenuItem";
            this.beschikbareTalenToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.beschikbareTalenToolStripMenuItem.Text = "Beschikbare talen";
            // 
            // nederlandsToolStripMenuItem
            // 
            this.nederlandsToolStripMenuItem.Checked = true;
            this.nederlandsToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.nederlandsToolStripMenuItem.Name = "nederlandsToolStripMenuItem";
            this.nederlandsToolStripMenuItem.Size = new System.Drawing.Size(134, 22);
            this.nederlandsToolStripMenuItem.Text = "Nederlands";
            // 
            // meldingenUitschakelenToolStripMenuItem
            // 
            this.meldingenUitschakelenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.inschakelenToolStripMenuItem,
            this.ontvangerToolStripMenuItem});
            this.meldingenUitschakelenToolStripMenuItem.Name = "meldingenUitschakelenToolStripMenuItem";
            this.meldingenUitschakelenToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.meldingenUitschakelenToolStripMenuItem.Text = "Meldingen ";
            // 
            // inschakelenToolStripMenuItem
            // 
            this.inschakelenToolStripMenuItem.Checked = true;
            this.inschakelenToolStripMenuItem.CheckOnClick = true;
            this.inschakelenToolStripMenuItem.CheckState = System.Windows.Forms.CheckState.Checked;
            this.inschakelenToolStripMenuItem.Name = "inschakelenToolStripMenuItem";
            this.inschakelenToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.inschakelenToolStripMenuItem.Text = "Ingeschakeld";
            // 
            // ontvangerToolStripMenuItem
            // 
            this.ontvangerToolStripMenuItem.Name = "ontvangerToolStripMenuItem";
            this.ontvangerToolStripMenuItem.Size = new System.Drawing.Size(181, 22);
            this.ontvangerToolStripMenuItem.Text = "Ontvangers beheren";
            this.ontvangerToolStripMenuItem.Click += new System.EventHandler(this.OntvangerToevoegenToolStripMenuItem_Click);
            // 
            // helpToolStripMenuItem
            // 
            this.helpToolStripMenuItem.Name = "helpToolStripMenuItem";
            this.helpToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.helpToolStripMenuItem.Text = "Help";
            this.helpToolStripMenuItem.Click += new System.EventHandler(this.HelpToolStripMenuItem_Click);
            // 
            // contactToolStripMenuItem
            // 
            this.contactToolStripMenuItem.Name = "contactToolStripMenuItem";
            this.contactToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.contactToolStripMenuItem.Text = "Contact";
            this.contactToolStripMenuItem.Click += new System.EventHandler(this.ContactToolStripMenuItem_Click);
            // 
            // fullScreenToolStripMenuItem
            // 
            this.fullScreenToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fullScreenToolStripMenuItem2,
            this.maximaalToolStripMenuItem1,
            this.minimaalToolStripMenuItem1});
            this.fullScreenToolStripMenuItem.Name = "fullScreenToolStripMenuItem";
            this.fullScreenToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.fullScreenToolStripMenuItem.Text = "Scherm grootte";
            // 
            // fullScreenToolStripMenuItem2
            // 
            this.fullScreenToolStripMenuItem2.Name = "fullScreenToolStripMenuItem2";
            this.fullScreenToolStripMenuItem2.Size = new System.Drawing.Size(130, 22);
            this.fullScreenToolStripMenuItem2.Text = "Full screen";
            this.fullScreenToolStripMenuItem2.Click += new System.EventHandler(this.fullScreenToolStripMenuItem2_Click);
            // 
            // maximaalToolStripMenuItem1
            // 
            this.maximaalToolStripMenuItem1.Name = "maximaalToolStripMenuItem1";
            this.maximaalToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.maximaalToolStripMenuItem1.Text = "Maximaal";
            this.maximaalToolStripMenuItem1.Click += new System.EventHandler(this.maximaalToolStripMenuItem1_Click);
            // 
            // minimaalToolStripMenuItem1
            // 
            this.minimaalToolStripMenuItem1.Name = "minimaalToolStripMenuItem1";
            this.minimaalToolStripMenuItem1.Size = new System.Drawing.Size(130, 22);
            this.minimaalToolStripMenuItem1.Text = "Minimaal";
            this.minimaalToolStripMenuItem1.Click += new System.EventHandler(this.minimaalToolStripMenuItem1_Click);
            // 
            // meldingServiceToolStripMenuItem
            // 
            this.meldingServiceToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.minutenToolStripMenuItem,
            this.minutenToolStripMenuItem1,
            this.minutenToolStripMenuItem2});
            this.meldingServiceToolStripMenuItem.Name = "meldingServiceToolStripMenuItem";
            this.meldingServiceToolStripMenuItem.Size = new System.Drawing.Size(169, 22);
            this.meldingServiceToolStripMenuItem.Text = "Melding service";
            // 
            // minutenToolStripMenuItem
            // 
            this.minutenToolStripMenuItem.Name = "minutenToolStripMenuItem";
            this.minutenToolStripMenuItem.Size = new System.Drawing.Size(152, 22);
            this.minutenToolStripMenuItem.Text = "15 Minuten";
            this.minutenToolStripMenuItem.Click += new System.EventHandler(this.MinutenToolStripMenuItem_Click);
            // 
            // minutenToolStripMenuItem1
            // 
            this.minutenToolStripMenuItem1.Name = "minutenToolStripMenuItem1";
            this.minutenToolStripMenuItem1.Size = new System.Drawing.Size(152, 22);
            this.minutenToolStripMenuItem1.Text = "30 Minuten";
            this.minutenToolStripMenuItem1.Click += new System.EventHandler(this.MinutenToolStripMenuItem1_Click);
            // 
            // minutenToolStripMenuItem2
            // 
            this.minutenToolStripMenuItem2.Name = "minutenToolStripMenuItem2";
            this.minutenToolStripMenuItem2.Size = new System.Drawing.Size(152, 22);
            this.minutenToolStripMenuItem2.Text = "60 Minuten";
            this.minutenToolStripMenuItem2.Click += new System.EventHandler(this.MinutenToolStripMenuItem2_Click);
            // 
            // btnInstellingen
            // 
            this.btnInstellingen.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.btnInstellingen.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.btnInstellingen.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnInstellingen.BackgroundImage")));
            this.btnInstellingen.DialogResult = System.Windows.Forms.DialogResult.No;
            this.btnInstellingen.Location = new System.Drawing.Point(890, -1);
            this.btnInstellingen.Name = "btnInstellingen";
            this.btnInstellingen.Size = new System.Drawing.Size(51, 50);
            this.btnInstellingen.TabIndex = 131;
            this.btnInstellingen.UseVisualStyleBackColor = false;
            this.btnInstellingen.Click += new System.EventHandler(this.BtnInstellingen_Click);
            // 
            // GrafiekTemperatuur
            // 
            this.GrafiekTemperatuur.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrafiekTemperatuur.BackColor = System.Drawing.SystemColors.Control;
            this.GrafiekTemperatuur.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea12.Name = "ChartArea1";
            this.GrafiekTemperatuur.ChartAreas.Add(chartArea12);
            this.GrafiekTemperatuur.DataSource = this.tblTemperatureBindingSource;
            legend12.Name = "Legend1";
            this.GrafiekTemperatuur.Legends.Add(legend12);
            this.GrafiekTemperatuur.Location = new System.Drawing.Point(0, 298);
            this.GrafiekTemperatuur.Name = "GrafiekTemperatuur";
            series12.ChartArea = "ChartArea1";
            series12.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series12.Legend = "Legend1";
            series12.Name = "Sensor 1: Celsius";
            series12.XValueMember = "DateTime";
            series12.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series12.YValueMembers = "TemperatureCelsius";
            series12.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.GrafiekTemperatuur.Series.Add(series12);
            this.GrafiekTemperatuur.Size = new System.Drawing.Size(993, 420);
            this.GrafiekTemperatuur.TabIndex = 135;
            title12.Name = "Title1";
            this.GrafiekTemperatuur.Titles.Add(title12);
            // 
            // tblTemperatureBindingSource
            // 
            this.tblTemperatureBindingSource.DataMember = "tbl_Temperature";
            this.tblTemperatureBindingSource.DataSource = this.temperatuurDataSet;
            // 
            // temperatuurDataSet
            // 
            this.temperatuurDataSet.DataSetName = "temperatuurDataSet";
            this.temperatuurDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema;
            // 
            // timer1
            // 
            this.timer1.Tick += new System.EventHandler(this.Timer1_Tick);
            // 
            // BtnTimerStart1
            // 
            this.BtnTimerStart1.Location = new System.Drawing.Point(675, 273);
            this.BtnTimerStart1.Name = "BtnTimerStart1";
            this.BtnTimerStart1.Size = new System.Drawing.Size(75, 23);
            this.BtnTimerStart1.TabIndex = 138;
            this.BtnTimerStart1.Text = "Start ";
            this.BtnTimerStart1.UseVisualStyleBackColor = true;
            this.BtnTimerStart1.Click += new System.EventHandler(this.BtnTimerStart_Click);
            // 
            // BtnTimerStop1
            // 
            this.BtnTimerStop1.Location = new System.Drawing.Point(766, 273);
            this.BtnTimerStop1.Name = "BtnTimerStop1";
            this.BtnTimerStop1.Size = new System.Drawing.Size(75, 23);
            this.BtnTimerStop1.TabIndex = 139;
            this.BtnTimerStop1.Text = "Stop ";
            this.BtnTimerStop1.UseVisualStyleBackColor = true;
            this.BtnTimerStop1.Click += new System.EventHandler(this.BtnTimerStop_Click);
            // 
            // LblRealTime1
            // 
            this.LblRealTime1.AutoSize = true;
            this.LblRealTime1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblRealTime1.Location = new System.Drawing.Point(591, 279);
            this.LblRealTime1.Name = "LblRealTime1";
            this.LblRealTime1.Size = new System.Drawing.Size(86, 13);
            this.LblRealTime1.TabIndex = 140;
            this.LblRealTime1.Text = "Realtime grafiek:";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(931, 510);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(0, 13);
            this.label1.TabIndex = 141;
            this.label1.Visible = false;
            // 
            // timer2
            // 
            this.timer2.Tick += new System.EventHandler(this.Timer2_Tick);
            // 
            // tbl_TemperatureTableAdapter
            // 
            this.tbl_TemperatureTableAdapter.ClearBeforeFill = true;
            // 
            // GrafiekKelvin1
            // 
            this.GrafiekKelvin1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrafiekKelvin1.BackColor = System.Drawing.SystemColors.Control;
            this.GrafiekKelvin1.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea11.Name = "ChartArea1";
            this.GrafiekKelvin1.ChartAreas.Add(chartArea11);
            this.GrafiekKelvin1.DataSource = this.tblTemperatureBindingSource;
            legend11.Name = "Legend1";
            this.GrafiekKelvin1.Legends.Add(legend11);
            this.GrafiekKelvin1.Location = new System.Drawing.Point(0, 298);
            this.GrafiekKelvin1.Name = "GrafiekKelvin1";
            series11.ChartArea = "ChartArea1";
            series11.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series11.Legend = "Legend1";
            series11.Name = "Sensor 1: Kelvin";
            series11.XValueMember = "DateTime";
            series11.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series11.YValueMembers = "TemperatureKelvin";
            series11.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.GrafiekKelvin1.Series.Add(series11);
            this.GrafiekKelvin1.Size = new System.Drawing.Size(993, 420);
            this.GrafiekKelvin1.TabIndex = 147;
            title11.Name = "Title1";
            this.GrafiekKelvin1.Titles.Add(title11);
            this.GrafiekKelvin1.Visible = false;
            // 
            // grafiekFarhenheid1
            // 
            this.grafiekFarhenheid1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grafiekFarhenheid1.BackColor = System.Drawing.SystemColors.Control;
            this.grafiekFarhenheid1.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea10.Name = "ChartArea1";
            this.grafiekFarhenheid1.ChartAreas.Add(chartArea10);
            this.grafiekFarhenheid1.DataSource = this.tblTemperatureBindingSource;
            legend10.Name = "Legend1";
            this.grafiekFarhenheid1.Legends.Add(legend10);
            this.grafiekFarhenheid1.Location = new System.Drawing.Point(0, 298);
            this.grafiekFarhenheid1.Name = "grafiekFarhenheid1";
            series10.ChartArea = "ChartArea1";
            series10.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series10.Legend = "Legend1";
            series10.Name = "Sensor 1: Farhenheid";
            series10.XValueMember = "DateTime";
            series10.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series10.YValueMembers = "TemperatureFarhenheid";
            series10.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.grafiekFarhenheid1.Series.Add(series10);
            this.grafiekFarhenheid1.Size = new System.Drawing.Size(993, 420);
            this.grafiekFarhenheid1.TabIndex = 148;
            title10.Name = "Title1";
            this.grafiekFarhenheid1.Titles.Add(title10);
            this.grafiekFarhenheid1.Visible = false;
            // 
            // GrafiekTemperatuur2
            // 
            this.GrafiekTemperatuur2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrafiekTemperatuur2.BackColor = System.Drawing.SystemColors.Control;
            this.GrafiekTemperatuur2.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea9.Name = "ChartArea1";
            this.GrafiekTemperatuur2.ChartAreas.Add(chartArea9);
            this.GrafiekTemperatuur2.DataSource = this.tblTemperatureBindingSource;
            legend9.Name = "Legend1";
            this.GrafiekTemperatuur2.Legends.Add(legend9);
            this.GrafiekTemperatuur2.Location = new System.Drawing.Point(0, 298);
            this.GrafiekTemperatuur2.Name = "GrafiekTemperatuur2";
            series9.ChartArea = "ChartArea1";
            series9.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series9.Legend = "Legend1";
            series9.Name = "Sensor 2: Celsius";
            series9.XValueMember = "DateTime";
            series9.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series9.YValueMembers = "TemperatureCelsius";
            series9.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.GrafiekTemperatuur2.Series.Add(series9);
            this.GrafiekTemperatuur2.Size = new System.Drawing.Size(993, 420);
            this.GrafiekTemperatuur2.TabIndex = 149;
            title9.Name = "Title1";
            this.GrafiekTemperatuur2.Titles.Add(title9);
            this.GrafiekTemperatuur2.Visible = false;
            // 
            // grafiekFarhenheid2
            // 
            this.grafiekFarhenheid2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.grafiekFarhenheid2.BackColor = System.Drawing.SystemColors.Control;
            this.grafiekFarhenheid2.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea8.Name = "ChartArea1";
            this.grafiekFarhenheid2.ChartAreas.Add(chartArea8);
            this.grafiekFarhenheid2.DataSource = this.tblTemperatureBindingSource;
            legend8.Name = "Legend1";
            this.grafiekFarhenheid2.Legends.Add(legend8);
            this.grafiekFarhenheid2.Location = new System.Drawing.Point(0, 298);
            this.grafiekFarhenheid2.Name = "grafiekFarhenheid2";
            series8.ChartArea = "ChartArea1";
            series8.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series8.Legend = "Legend1";
            series8.Name = "Sensor 2: Farhenheid";
            series8.XValueMember = "DateTime";
            series8.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series8.YValueMembers = "TemperatureFarhenheid";
            series8.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.grafiekFarhenheid2.Series.Add(series8);
            this.grafiekFarhenheid2.Size = new System.Drawing.Size(993, 420);
            this.grafiekFarhenheid2.TabIndex = 150;
            title8.Name = "Title1";
            this.grafiekFarhenheid2.Titles.Add(title8);
            this.grafiekFarhenheid2.Visible = false;
            // 
            // GrafiekKelvin2
            // 
            this.GrafiekKelvin2.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.GrafiekKelvin2.BackColor = System.Drawing.SystemColors.Control;
            this.GrafiekKelvin2.BackImageTransparentColor = System.Drawing.Color.Transparent;
            chartArea7.Name = "ChartArea1";
            this.GrafiekKelvin2.ChartAreas.Add(chartArea7);
            this.GrafiekKelvin2.DataSource = this.tblTemperatureBindingSource;
            legend7.Name = "Legend1";
            this.GrafiekKelvin2.Legends.Add(legend7);
            this.GrafiekKelvin2.Location = new System.Drawing.Point(0, 298);
            this.GrafiekKelvin2.Name = "GrafiekKelvin2";
            series7.ChartArea = "ChartArea1";
            series7.ChartType = System.Windows.Forms.DataVisualization.Charting.SeriesChartType.Line;
            series7.Legend = "Legend1";
            series7.Name = "Sensor 2: Kelvin";
            series7.XValueMember = "DateTime";
            series7.XValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.DateTime;
            series7.YValueMembers = "TemperatureKelvin";
            series7.YValuesPerPoint = 2;
            series7.YValueType = System.Windows.Forms.DataVisualization.Charting.ChartValueType.Double;
            this.GrafiekKelvin2.Series.Add(series7);
            this.GrafiekKelvin2.Size = new System.Drawing.Size(993, 420);
            this.GrafiekKelvin2.TabIndex = 151;
            title7.Name = "Title1";
            this.GrafiekKelvin2.Titles.Add(title7);
            this.GrafiekKelvin2.Visible = false;
            // 
            // BtnRefreshLocation
            // 
            this.BtnRefreshLocation.Location = new System.Drawing.Point(0, 0);
            this.BtnRefreshLocation.Name = "BtnRefreshLocation";
            this.BtnRefreshLocation.Size = new System.Drawing.Size(75, 23);
            this.BtnRefreshLocation.TabIndex = 157;
            // 
            // PnlSensor2
            // 
            this.PnlSensor2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PnlSensor2.Controls.Add(this.label6);
            this.PnlSensor2.Controls.Add(this.label4);
            this.PnlSensor2.Controls.Add(this.label5);
            this.PnlSensor2.Controls.Add(this.BtnS22);
            this.PnlSensor2.Controls.Add(this.Btns21);
            this.PnlSensor2.Controls.Add(this.BtnS2);
            this.PnlSensor2.Controls.Add(this.LblSensor2);
            this.PnlSensor2.Controls.Add(this.TxbSelectedSensor2);
            this.PnlSensor2.Controls.Add(this.TbMinimumTemperatuur2);
            this.PnlSensor2.Controls.Add(this.LblMinimumTemperatuur2);
            this.PnlSensor2.Controls.Add(this.TbMaximumTemperatuur2);
            this.PnlSensor2.Controls.Add(this.LblMaximumTemperatuur2);
            this.PnlSensor2.Controls.Add(this.RdbFarhenheid2);
            this.PnlSensor2.Controls.Add(this.RdbKelvin2);
            this.PnlSensor2.Controls.Add(this.RdbCelsius2);
            this.PnlSensor2.Controls.Add(this.BtnSettingsSensor2);
            this.PnlSensor2.Location = new System.Drawing.Point(331, 61);
            this.PnlSensor2.Name = "PnlSensor2";
            this.PnlSensor2.Size = new System.Drawing.Size(266, 205);
            this.PnlSensor2.TabIndex = 154;
            // 
            // BtnS2
            // 
            this.BtnS2.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.BtnS2.Location = new System.Drawing.Point(9, 12);
            this.BtnS2.Name = "BtnS2";
            this.BtnS2.Size = new System.Drawing.Size(22, 19);
            this.BtnS2.TabIndex = 163;
            this.BtnS2.UseVisualStyleBackColor = false;
            // 
            // LblSensor2
            // 
            this.LblSensor2.AutoSize = true;
            this.LblSensor2.Location = new System.Drawing.Point(37, 15);
            this.LblSensor2.Name = "LblSensor2";
            this.LblSensor2.Size = new System.Drawing.Size(49, 13);
            this.LblSensor2.TabIndex = 161;
            this.LblSensor2.Text = "Sensor 2";
            // 
            // TxbSelectedSensor2
            // 
            this.TxbSelectedSensor2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxbSelectedSensor2.Location = new System.Drawing.Point(40, 32);
            this.TxbSelectedSensor2.Name = "TxbSelectedSensor2";
            this.TxbSelectedSensor2.ReadOnly = true;
            this.TxbSelectedSensor2.Size = new System.Drawing.Size(164, 20);
            this.TxbSelectedSensor2.TabIndex = 151;
            // 
            // TbMinimumTemperatuur2
            // 
            this.TbMinimumTemperatuur2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbMinimumTemperatuur2.Location = new System.Drawing.Point(154, 57);
            this.TbMinimumTemperatuur2.Name = "TbMinimumTemperatuur2";
            this.TbMinimumTemperatuur2.ReadOnly = true;
            this.TbMinimumTemperatuur2.Size = new System.Drawing.Size(49, 20);
            this.TbMinimumTemperatuur2.TabIndex = 157;
            // 
            // LblMinimumTemperatuur2
            // 
            this.LblMinimumTemperatuur2.AutoSize = true;
            this.LblMinimumTemperatuur2.Location = new System.Drawing.Point(37, 61);
            this.LblMinimumTemperatuur2.Name = "LblMinimumTemperatuur2";
            this.LblMinimumTemperatuur2.Size = new System.Drawing.Size(118, 13);
            this.LblMinimumTemperatuur2.TabIndex = 159;
            this.LblMinimumTemperatuur2.Text = "Minumum Temperatuur:";
            // 
            // TbMaximumTemperatuur2
            // 
            this.TbMaximumTemperatuur2.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbMaximumTemperatuur2.Location = new System.Drawing.Point(154, 83);
            this.TbMaximumTemperatuur2.Name = "TbMaximumTemperatuur2";
            this.TbMaximumTemperatuur2.ReadOnly = true;
            this.TbMaximumTemperatuur2.Size = new System.Drawing.Size(49, 20);
            this.TbMaximumTemperatuur2.TabIndex = 158;
            // 
            // LblMaximumTemperatuur2
            // 
            this.LblMaximumTemperatuur2.AutoSize = true;
            this.LblMaximumTemperatuur2.Location = new System.Drawing.Point(36, 86);
            this.LblMaximumTemperatuur2.Name = "LblMaximumTemperatuur2";
            this.LblMaximumTemperatuur2.Size = new System.Drawing.Size(117, 13);
            this.LblMaximumTemperatuur2.TabIndex = 160;
            this.LblMaximumTemperatuur2.Text = "Maximum Temperatuur:";
            // 
            // RdbFarhenheid2
            // 
            this.RdbFarhenheid2.AutoSize = true;
            this.RdbFarhenheid2.Location = new System.Drawing.Point(40, 152);
            this.RdbFarhenheid2.Name = "RdbFarhenheid2";
            this.RdbFarhenheid2.Size = new System.Drawing.Size(78, 17);
            this.RdbFarhenheid2.TabIndex = 153;
            this.RdbFarhenheid2.Text = "Farhenheid";
            this.RdbFarhenheid2.UseVisualStyleBackColor = true;
            this.RdbFarhenheid2.Click += new System.EventHandler(this.RdbFarhenheid2_Click);
            // 
            // RdbKelvin2
            // 
            this.RdbKelvin2.AutoSize = true;
            this.RdbKelvin2.Location = new System.Drawing.Point(40, 129);
            this.RdbKelvin2.Name = "RdbKelvin2";
            this.RdbKelvin2.Size = new System.Drawing.Size(54, 17);
            this.RdbKelvin2.TabIndex = 152;
            this.RdbKelvin2.Text = "Kelvin";
            this.RdbKelvin2.UseVisualStyleBackColor = true;
            this.RdbKelvin2.Click += new System.EventHandler(this.RdbKelvin2_Click);
            // 
            // RdbCelsius2
            // 
            this.RdbCelsius2.AutoSize = true;
            this.RdbCelsius2.Location = new System.Drawing.Point(40, 106);
            this.RdbCelsius2.Name = "RdbCelsius2";
            this.RdbCelsius2.Size = new System.Drawing.Size(58, 17);
            this.RdbCelsius2.TabIndex = 151;
            this.RdbCelsius2.Text = "Celsius";
            this.RdbCelsius2.UseVisualStyleBackColor = true;
            this.RdbCelsius2.Click += new System.EventHandler(this.RdbCelsius2_Click);
            // 
            // BtnSettingsSensor2
            // 
            this.BtnSettingsSensor2.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnSettingsSensor2.BackgroundImage")));
            this.BtnSettingsSensor2.Location = new System.Drawing.Point(235, 175);
            this.BtnSettingsSensor2.Name = "BtnSettingsSensor2";
            this.BtnSettingsSensor2.Size = new System.Drawing.Size(31, 30);
            this.BtnSettingsSensor2.TabIndex = 150;
            this.BtnSettingsSensor2.UseVisualStyleBackColor = true;
            this.BtnSettingsSensor2.Click += new System.EventHandler(this.BtnSettingsSensor2_Click);
            // 
            // PnlHeader
            // 
            this.PnlHeader.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PnlHeader.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PnlHeader.Controls.Add(this.label2);
            this.PnlHeader.Controls.Add(this.BtnLogout);
            this.PnlHeader.Controls.Add(this.btnInstellingen);
            this.PnlHeader.Location = new System.Drawing.Point(0, 0);
            this.PnlHeader.Name = "PnlHeader";
            this.PnlHeader.Size = new System.Drawing.Size(993, 49);
            this.PnlHeader.TabIndex = 155;
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label2.Location = new System.Drawing.Point(11, 13);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(457, 20);
            this.label2.TabIndex = 164;
            this.label2.Text = "Temperatuur grafiek van Erwin Torrenga en Nordin van der Leije";
            // 
            // PnlFooter
            // 
            this.PnlFooter.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.PnlFooter.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PnlFooter.Controls.Add(this.TxbPcUser);
            this.PnlFooter.Controls.Add(this.TxbLastConnTime);
            this.PnlFooter.Controls.Add(this.label3);
            this.PnlFooter.Controls.Add(this.TxbUserLoggedIn);
            this.PnlFooter.Controls.Add(this.LblUserApp);
            this.PnlFooter.Controls.Add(this.LblPc);
            this.PnlFooter.Controls.Add(this.BtnStatusSqlConnection);
            this.PnlFooter.Controls.Add(this.LblStatusSql);
            this.PnlFooter.Location = new System.Drawing.Point(0, 708);
            this.PnlFooter.Name = "PnlFooter";
            this.PnlFooter.Size = new System.Drawing.Size(993, 50);
            this.PnlFooter.TabIndex = 156;
            // 
            // TxbPcUser
            // 
            this.TxbPcUser.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.TxbPcUser.Location = new System.Drawing.Point(890, 15);
            this.TxbPcUser.Name = "TxbPcUser";
            this.TxbPcUser.ReadOnly = true;
            this.TxbPcUser.Size = new System.Drawing.Size(100, 20);
            this.TxbPcUser.TabIndex = 168;
            // 
            // TxbLastConnTime
            // 
            this.TxbLastConnTime.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.TxbLastConnTime.Location = new System.Drawing.Point(460, 15);
            this.TxbLastConnTime.Name = "TxbLastConnTime";
            this.TxbLastConnTime.ReadOnly = true;
            this.TxbLastConnTime.Size = new System.Drawing.Size(108, 20);
            this.TxbLastConnTime.TabIndex = 169;
            // 
            // label3
            // 
            this.label3.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(328, 18);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(127, 13);
            this.label3.TabIndex = 164;
            this.label3.Text = "Laatste data in database:";
            // 
            // TxbUserLoggedIn
            // 
            this.TxbUserLoggedIn.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.TxbUserLoggedIn.Location = new System.Drawing.Point(727, 15);
            this.TxbUserLoggedIn.Name = "TxbUserLoggedIn";
            this.TxbUserLoggedIn.ReadOnly = true;
            this.TxbUserLoggedIn.Size = new System.Drawing.Size(100, 20);
            this.TxbUserLoggedIn.TabIndex = 163;
            // 
            // LblUserApp
            // 
            this.LblUserApp.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LblUserApp.AutoSize = true;
            this.LblUserApp.Location = new System.Drawing.Point(654, 18);
            this.LblUserApp.Name = "LblUserApp";
            this.LblUserApp.Size = new System.Drawing.Size(67, 13);
            this.LblUserApp.TabIndex = 162;
            this.LblUserApp.Text = "Ingelogd als:";
            // 
            // LblPc
            // 
            this.LblPc.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LblPc.AutoSize = true;
            this.LblPc.Location = new System.Drawing.Point(833, 18);
            this.LblPc.Name = "LblPc";
            this.LblPc.Size = new System.Drawing.Size(55, 13);
            this.LblPc.TabIndex = 160;
            this.LblPc.Text = "Computer:";
            // 
            // BtnStatusSqlConnection
            // 
            this.BtnStatusSqlConnection.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.BtnStatusSqlConnection.BackColor = System.Drawing.SystemColors.Control;
            this.BtnStatusSqlConnection.Location = new System.Drawing.Point(177, 15);
            this.BtnStatusSqlConnection.Name = "BtnStatusSqlConnection";
            this.BtnStatusSqlConnection.Size = new System.Drawing.Size(75, 23);
            this.BtnStatusSqlConnection.TabIndex = 1;
            this.BtnStatusSqlConnection.UseVisualStyleBackColor = false;
            this.BtnStatusSqlConnection.Click += new System.EventHandler(this.BtnStatusSqlConnection_Click);
            // 
            // LblStatusSql
            // 
            this.LblStatusSql.Anchor = System.Windows.Forms.AnchorStyles.Left;
            this.LblStatusSql.AutoSize = true;
            this.LblStatusSql.Location = new System.Drawing.Point(12, 18);
            this.LblStatusSql.Name = "LblStatusSql";
            this.LblStatusSql.Size = new System.Drawing.Size(159, 13);
            this.LblStatusSql.TabIndex = 0;
            this.LblStatusSql.Text = "Status verbinding met database:";
            // 
            // fullScreenToolStripMenuItem1
            // 
            this.fullScreenToolStripMenuItem1.Name = "fullScreenToolStripMenuItem1";
            this.fullScreenToolStripMenuItem1.Size = new System.Drawing.Size(32, 19);
            // 
            // maximaalToolStripMenuItem
            // 
            this.maximaalToolStripMenuItem.Name = "maximaalToolStripMenuItem";
            this.maximaalToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // minimaalToolStripMenuItem
            // 
            this.minimaalToolStripMenuItem.Name = "minimaalToolStripMenuItem";
            this.minimaalToolStripMenuItem.Size = new System.Drawing.Size(32, 19);
            // 
            // TimerStatusSQL
            // 
            this.TimerStatusSQL.Interval = 1000;
            this.TimerStatusSQL.Tick += new System.EventHandler(this.TimerStatusSensor_Tick);
            // 
            // LblSensor1Active
            // 
            this.LblSensor1Active.AutoSize = true;
            this.LblSensor1Active.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSensor1Active.Location = new System.Drawing.Point(375, 311);
            this.LblSensor1Active.Name = "LblSensor1Active";
            this.LblSensor1Active.Size = new System.Drawing.Size(93, 24);
            this.LblSensor1Active.TabIndex = 159;
            this.LblSensor1Active.Text = "Sensor 1";
            // 
            // LblSensor2Active
            // 
            this.LblSensor2Active.AutoSize = true;
            this.LblSensor2Active.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, ((System.Drawing.FontStyle)((System.Drawing.FontStyle.Bold | System.Drawing.FontStyle.Underline))), System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.LblSensor2Active.Location = new System.Drawing.Point(375, 311);
            this.LblSensor2Active.Name = "LblSensor2Active";
            this.LblSensor2Active.Size = new System.Drawing.Size(93, 24);
            this.LblSensor2Active.TabIndex = 160;
            this.LblSensor2Active.Text = "Sensor 2";
            // 
            // LblMaximumTemperatuur1
            // 
            this.LblMaximumTemperatuur1.AutoSize = true;
            this.LblMaximumTemperatuur1.Location = new System.Drawing.Point(52, 86);
            this.LblMaximumTemperatuur1.Name = "LblMaximumTemperatuur1";
            this.LblMaximumTemperatuur1.Size = new System.Drawing.Size(117, 13);
            this.LblMaximumTemperatuur1.TabIndex = 119;
            this.LblMaximumTemperatuur1.Text = "Maximum Temperatuur:";
            // 
            // TbMaximumTemperatuur1
            // 
            this.TbMaximumTemperatuur1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbMaximumTemperatuur1.Location = new System.Drawing.Point(170, 83);
            this.TbMaximumTemperatuur1.Name = "TbMaximumTemperatuur1";
            this.TbMaximumTemperatuur1.ReadOnly = true;
            this.TbMaximumTemperatuur1.Size = new System.Drawing.Size(49, 20);
            this.TbMaximumTemperatuur1.TabIndex = 115;
            // 
            // LblMinimumTemperatuur1
            // 
            this.LblMinimumTemperatuur1.AutoSize = true;
            this.LblMinimumTemperatuur1.Location = new System.Drawing.Point(52, 61);
            this.LblMinimumTemperatuur1.Name = "LblMinimumTemperatuur1";
            this.LblMinimumTemperatuur1.Size = new System.Drawing.Size(118, 13);
            this.LblMinimumTemperatuur1.TabIndex = 118;
            this.LblMinimumTemperatuur1.Text = "Minumum Temperatuur:";
            // 
            // TbMinimumTemperatuur1
            // 
            this.TbMinimumTemperatuur1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TbMinimumTemperatuur1.Location = new System.Drawing.Point(170, 57);
            this.TbMinimumTemperatuur1.Name = "TbMinimumTemperatuur1";
            this.TbMinimumTemperatuur1.ReadOnly = true;
            this.TbMinimumTemperatuur1.Size = new System.Drawing.Size(49, 20);
            this.TbMinimumTemperatuur1.TabIndex = 114;
            // 
            // RdbCelsius1
            // 
            this.RdbCelsius1.AutoSize = true;
            this.RdbCelsius1.Location = new System.Drawing.Point(55, 106);
            this.RdbCelsius1.Name = "RdbCelsius1";
            this.RdbCelsius1.Size = new System.Drawing.Size(58, 17);
            this.RdbCelsius1.TabIndex = 146;
            this.RdbCelsius1.Text = "Celsius";
            this.RdbCelsius1.UseVisualStyleBackColor = true;
            this.RdbCelsius1.Click += new System.EventHandler(this.RdbCelsius1_Click);
            // 
            // RdbKelvin1
            // 
            this.RdbKelvin1.AutoSize = true;
            this.RdbKelvin1.Location = new System.Drawing.Point(55, 129);
            this.RdbKelvin1.Name = "RdbKelvin1";
            this.RdbKelvin1.Size = new System.Drawing.Size(54, 17);
            this.RdbKelvin1.TabIndex = 147;
            this.RdbKelvin1.Text = "Kelvin";
            this.RdbKelvin1.UseVisualStyleBackColor = true;
            this.RdbKelvin1.Click += new System.EventHandler(this.RdbKelvin1_Click);
            // 
            // RdbFarhenheid1
            // 
            this.RdbFarhenheid1.AutoSize = true;
            this.RdbFarhenheid1.Location = new System.Drawing.Point(55, 152);
            this.RdbFarhenheid1.Name = "RdbFarhenheid1";
            this.RdbFarhenheid1.Size = new System.Drawing.Size(78, 17);
            this.RdbFarhenheid1.TabIndex = 148;
            this.RdbFarhenheid1.Text = "Farhenheid";
            this.RdbFarhenheid1.UseVisualStyleBackColor = true;
            this.RdbFarhenheid1.Click += new System.EventHandler(this.RdbFarhenheid1_Click);
            // 
            // BtnSettingsSensor1
            // 
            this.BtnSettingsSensor1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnSettingsSensor1.BackgroundImage")));
            this.BtnSettingsSensor1.Location = new System.Drawing.Point(235, 175);
            this.BtnSettingsSensor1.Name = "BtnSettingsSensor1";
            this.BtnSettingsSensor1.Size = new System.Drawing.Size(31, 30);
            this.BtnSettingsSensor1.TabIndex = 149;
            this.BtnSettingsSensor1.UseVisualStyleBackColor = true;
            this.BtnSettingsSensor1.Click += new System.EventHandler(this.BtnSettingsSensor1_Click);
            // 
            // TxbSelectedSensor1
            // 
            this.TxbSelectedSensor1.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.TxbSelectedSensor1.Location = new System.Drawing.Point(55, 32);
            this.TxbSelectedSensor1.Name = "TxbSelectedSensor1";
            this.TxbSelectedSensor1.ReadOnly = true;
            this.TxbSelectedSensor1.Size = new System.Drawing.Size(164, 20);
            this.TxbSelectedSensor1.TabIndex = 150;
            // 
            // Btns1
            // 
            this.Btns1.BackColor = System.Drawing.SystemColors.ActiveCaptionText;
            this.Btns1.Location = new System.Drawing.Point(24, 13);
            this.Btns1.Name = "Btns1";
            this.Btns1.Size = new System.Drawing.Size(22, 19);
            this.Btns1.TabIndex = 161;
            this.Btns1.UseVisualStyleBackColor = false;
            // 
            // LblSensor1
            // 
            this.LblSensor1.AutoSize = true;
            this.LblSensor1.Location = new System.Drawing.Point(52, 16);
            this.LblSensor1.Name = "LblSensor1";
            this.LblSensor1.Size = new System.Drawing.Size(49, 13);
            this.LblSensor1.TabIndex = 162;
            this.LblSensor1.Text = "Sensor 1";
            // 
            // PnlSensor1
            // 
            this.PnlSensor1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.PnlSensor1.Controls.Add(this.LblSensor1);
            this.PnlSensor1.Controls.Add(this.Btns1);
            this.PnlSensor1.Controls.Add(this.TxbSelectedSensor1);
            this.PnlSensor1.Controls.Add(this.BtnSettingsSensor1);
            this.PnlSensor1.Controls.Add(this.RdbFarhenheid1);
            this.PnlSensor1.Controls.Add(this.RdbKelvin1);
            this.PnlSensor1.Controls.Add(this.RdbCelsius1);
            this.PnlSensor1.Controls.Add(this.TbMinimumTemperatuur1);
            this.PnlSensor1.Controls.Add(this.LblMinimumTemperatuur1);
            this.PnlSensor1.Controls.Add(this.TbMaximumTemperatuur1);
            this.PnlSensor1.Controls.Add(this.LblMaximumTemperatuur1);
            this.PnlSensor1.Location = new System.Drawing.Point(15, 61);
            this.PnlSensor1.Name = "PnlSensor1";
            this.PnlSensor1.Size = new System.Drawing.Size(266, 205);
            this.PnlSensor1.TabIndex = 153;
            // 
            // Btns21
            // 
            this.Btns21.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("Btns21.BackgroundImage")));
            this.Btns21.Location = new System.Drawing.Point(157, 176);
            this.Btns21.Name = "Btns21";
            this.Btns21.Size = new System.Drawing.Size(31, 30);
            this.Btns21.TabIndex = 164;
            this.Btns21.UseVisualStyleBackColor = false;
            // 
            // BtnS22
            // 
            this.BtnS22.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("BtnS22.BackgroundImage")));
            this.BtnS22.Location = new System.Drawing.Point(198, 176);
            this.BtnS22.Name = "BtnS22";
            this.BtnS22.Size = new System.Drawing.Size(31, 30);
            this.BtnS22.TabIndex = 165;
            this.BtnS22.UseVisualStyleBackColor = true;
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(89, 184);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(66, 13);
            this.label4.TabIndex = 161;
            this.label4.Text = "Weergeven:";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(165, 166);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(13, 13);
            this.label5.TabIndex = 161;
            this.label5.Text = "1";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(206, 166);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(13, 13);
            this.label6.TabIndex = 162;
            this.label6.Text = "2";
            // 
            // Temperatuur
            // 
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.None;
            this.BackColor = System.Drawing.SystemColors.Control;
            this.ClientSize = new System.Drawing.Size(993, 759);
            this.Controls.Add(this.LblSensor2Active);
            this.Controls.Add(this.LblSensor1Active);
            this.Controls.Add(this.PnlFooter);
            this.Controls.Add(this.PnlHeader);
            this.Controls.Add(this.BtnRefreshLocation);
            this.Controls.Add(this.PnlSensor2);
            this.Controls.Add(this.PnlSensor1);
            this.Controls.Add(this.GrafiekKelvin2);
            this.Controls.Add(this.grafiekFarhenheid2);
            this.Controls.Add(this.GrafiekTemperatuur2);
            this.Controls.Add(this.grafiekFarhenheid1);
            this.Controls.Add(this.BtnTimerStop1);
            this.Controls.Add(this.BtnTimerStart1);
            this.Controls.Add(this.GrafiekKelvin1);
            this.Controls.Add(this.LblRealTime1);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.GrafiekTemperatuur);
            this.Controls.Add(this.BtnOpvragenVanTot);
            this.Controls.Add(this.DtpTot);
            this.Controls.Add(this.LblTot);
            this.Controls.Add(this.LblVan);
            this.Controls.Add(this.DtpVan);
            this.Controls.Add(this.BtnLocatieSensorOpslaan);
            this.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Name = "Temperatuur";
            this.Text = "Temperatuur";
            this.TransparencyKey = System.Drawing.Color.Navy;
            this.FormClosed += new System.Windows.Forms.FormClosedEventHandler(this.Temperatuur_FormClosed);
            this.Shown += new System.EventHandler(this.Temperatuur_Shown);
            this.Instellingen.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekTemperatuur)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.tblTemperatureBindingSource)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.temperatuurDataSet)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekKelvin1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grafiekFarhenheid1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekTemperatuur2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.grafiekFarhenheid2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.GrafiekKelvin2)).EndInit();
            this.PnlSensor2.ResumeLayout(false);
            this.PnlSensor2.PerformLayout();
            this.PnlHeader.ResumeLayout(false);
            this.PnlHeader.PerformLayout();
            this.PnlFooter.ResumeLayout(false);
            this.PnlFooter.PerformLayout();
            this.PnlSensor1.ResumeLayout(false);
            this.PnlSensor1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Messaging.MessageQueue messageQueue1;
        private System.Windows.Forms.Button BtnOpvragenVanTot;
        private System.Windows.Forms.DateTimePicker DtpTot;
        private System.Windows.Forms.Label LblTot;
        private System.Windows.Forms.Label LblVan;
        private System.Windows.Forms.DateTimePicker DtpVan;
        private System.Windows.Forms.Button BtnLocatieSensorOpslaan;
        private System.Windows.Forms.Button BtnLogout;
        private System.Windows.Forms.ContextMenuStrip Instellingen;
        private System.Windows.Forms.ToolStripMenuItem test2ToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem roodToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem witToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem blauwToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem grijsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem groenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem geelToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem linksToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem websiteToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem mobieleApplicatieToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exportDataToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem beschikbareTalenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem nederlandsToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem meldingenUitschakelenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem helpToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem contactToolStripMenuItem;
        private System.Windows.Forms.Button btnInstellingen;
        private System.Windows.Forms.DataVisualization.Charting.Chart GrafiekTemperatuur;
        private System.Windows.Forms.Timer timer1;
        private System.Windows.Forms.Label LblRealTime1;
        private System.Windows.Forms.Button BtnTimerStop1;
        private System.Windows.Forms.Button BtnTimerStart1;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ToolStripMenuItem inschakelenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem ontvangerToolStripMenuItem;
        private System.Windows.Forms.Timer timer2;
        private System.Windows.Forms.ToolStripMenuItem orgineelToolStripMenuItem;
        private temperatuurDataSet temperatuurDataSet;
        private System.Windows.Forms.BindingSource tblTemperatureBindingSource;
        private temperatuurDataSetTableAdapters.tbl_TemperatureTableAdapter tbl_TemperatureTableAdapter;
        private System.Windows.Forms.DataVisualization.Charting.Chart grafiekFarhenheid1;
        private System.Windows.Forms.DataVisualization.Charting.Chart GrafiekKelvin1;
        private System.Windows.Forms.DataVisualization.Charting.Chart GrafiekTemperatuur2;
        private System.Windows.Forms.DataVisualization.Charting.Chart GrafiekKelvin2;
        private System.Windows.Forms.DataVisualization.Charting.Chart grafiekFarhenheid2;
        private System.Windows.Forms.Button BtnRefreshLocation;
        private System.Windows.Forms.Panel PnlSensor2;
        private System.Windows.Forms.Panel PnlHeader;
        private System.Windows.Forms.Panel PnlFooter;
        private System.Windows.Forms.TextBox TbMinimumTemperatuur2;
        private System.Windows.Forms.Label LblMinimumTemperatuur2;
        private System.Windows.Forms.TextBox TbMaximumTemperatuur2;
        private System.Windows.Forms.Label LblMaximumTemperatuur2;
        private System.Windows.Forms.RadioButton RdbFarhenheid2;
        private System.Windows.Forms.RadioButton RdbKelvin2;
        private System.Windows.Forms.RadioButton RdbCelsius2;
        private System.Windows.Forms.Button BtnSettingsSensor2;
        private System.Windows.Forms.TextBox TxbSelectedSensor2;
        private System.Windows.Forms.Label LblStatusSql;
        private System.Windows.Forms.Button BtnStatusSqlConnection;
        private System.Windows.Forms.Label LblUserApp;
        private System.Windows.Forms.Label LblPc;
        private System.Windows.Forms.TextBox TxbUserLoggedIn;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox TxbLastConnTime;
        private System.Windows.Forms.TextBox TxbPcUser;
        private System.Windows.Forms.ToolStripMenuItem fullScreenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fullScreenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem maximaalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minimaalToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem fullScreenToolStripMenuItem2;
        private System.Windows.Forms.ToolStripMenuItem maximaalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem minimaalToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem screenshotGrafiekToolStripMenuItem;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label LblSensor2;
        private System.Windows.Forms.Timer TimerStatusSQL;
        private System.Windows.Forms.Label LblSensor1Active;
        private System.Windows.Forms.Label LblSensor2Active;
        private System.Windows.Forms.Panel PnlSensor1;
        private System.Windows.Forms.Label LblSensor1;
        private System.Windows.Forms.Button Btns1;
        private System.Windows.Forms.TextBox TxbSelectedSensor1;
        private System.Windows.Forms.Button BtnSettingsSensor1;
        public System.Windows.Forms.RadioButton RdbFarhenheid1;
        public System.Windows.Forms.RadioButton RdbKelvin1;
        public System.Windows.Forms.RadioButton RdbCelsius1;
        private System.Windows.Forms.TextBox TbMinimumTemperatuur1;
        private System.Windows.Forms.Label LblMinimumTemperatuur1;
        private System.Windows.Forms.TextBox TbMaximumTemperatuur1;
        private System.Windows.Forms.Label LblMaximumTemperatuur1;
        private System.Windows.Forms.Button BtnS2;
        private System.Windows.Forms.ToolStripMenuItem meldingServiceToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minutenToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem minutenToolStripMenuItem1;
        private System.Windows.Forms.ToolStripMenuItem minutenToolStripMenuItem2;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Button BtnS22;
        private System.Windows.Forms.Button Btns21;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
    }
}

