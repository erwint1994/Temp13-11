﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace WindowsFormsApp1
{
    public static class Rights
    {
        public static int rights = 0;
        public static string username = "";
        public static int id = 1;
    }
}
