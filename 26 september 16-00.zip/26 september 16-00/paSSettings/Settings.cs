﻿using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace paSSettings
{
    public class Settings
    {
        //public Color BackColor { get; set; }

        //public void BgRed()
        //{
        //    roodToolStripMenuItem.Checked = true;
        //    this.BackColor = Color.Red;
        //    witToolStripMenuItem.Checked = false;
        //    blauwToolStripMenuItem.Checked = false;
        //    grijsToolStripMenuItem.Checked = false;
        //    groenToolStripMenuItem.Checked = false;
        //    geelToolStripMenuItem.Checked = false;
        //    orgineelToolStripMenuItem.Checked = false;
        //}
    }
}
